@php
	echo $link;
@endphp
