

@php
	echo $array['content'];
@endphp

 @php
	echo $array['url'];
@endphp


Thanks,<br>
{{ config('app.name') }}
